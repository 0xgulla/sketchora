/**
 * Drawing App Landing Page
 * 
 * Design Philosophy: Minimalist Brutalism
 * - Bold, oversized typography commanding attention
 * - Stark monochromatic palette with neon green accent
 * - Generous negative space for clarity
 * - Asymmetric layout with intentional imperfection
 * - Drawing-focused features and messaging
 */

import { useState } from "react";
import { ArrowRight, Palette, Layers, Zap, Share2, Brush, Lock } from "lucide-react";

export default function Home() {
  const [isHovering, setIsHovering] = useState(false);

  const handleLaunchClick = () => {
    // Replace with your actual app URL
    window.location.href = "https://app.example.com";
  };

  const features = [
    {
      icon: Brush,
      title: "Infinite Brushes",
      description: "Professional-grade brushes for every style and technique",
    },
    {
      icon: Layers,
      title: "Advanced Layers",
      description: "Organize your work with unlimited layers and blend modes",
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Optimized performance for smooth, responsive drawing",
    },
    {
      icon: Share2,
      title: "Collaborate",
      description: "Share and collaborate with other artists in real-time",
    },
    {
      icon: Palette,
      title: "Color Tools",
      description: "Advanced color management and palette creation",
    },
    {
      icon: Lock,
      title: "Your Work Secure",
      description: "Cloud backup and encryption for your creations",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Hero Section */}
      <section className="relative w-full min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663271119153/bgikhuDz7EaB7D8iQTKnxy/hero-geometric-dark-8HhUfkRwFLjQJcu5Cb3zCJ.webp')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        />
        
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/30 z-10" />

        {/* Content */}
        <div className="relative z-20 container max-w-4xl mx-auto px-4 py-20">
          <div className="flex flex-col gap-8 md:gap-12">
            {/* Main Headline */}
            <div className="space-y-6">
              <h1 className="text-white font-black leading-tight tracking-tight">
                Create Without Limits
              </h1>
              <div className="w-16 h-1 bg-accent" />
            </div>

            {/* Subheading */}
            <p className="text-lg md:text-xl text-gray-200 max-w-xl font-light leading-relaxed">
              The drawing app built for artists who demand precision, speed, and creative freedom. Sketch, paint, and design with professional-grade tools.
            </p>

            {/* CTA Button */}
            <div className="pt-4">
              <button
                onClick={handleLaunchClick}
                onMouseEnter={() => setIsHovering(true)}
                onMouseLeave={() => setIsHovering(false)}
                className="btn-brutalist group inline-flex items-center gap-3 bg-accent text-foreground border-2 border-accent hover:bg-foreground hover:text-accent"
              >
                Launch Drawing App
                <ArrowRight
                  size={20}
                  className={`transition-transform duration-300 ${
                    isHovering ? "translate-x-2" : ""
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid Section */}
      <section className="w-full bg-background py-20 md:py-32 border-t-4 border-foreground">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="mb-16">
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Built for Artists
            </h2>
            <div className="w-12 h-1 bg-accent" />
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div
                  key={index}
                  className="border-2 border-foreground p-8 hover:border-accent hover:bg-secondary transition-all duration-300 group"
                >
                  <IconComponent
                    size={32}
                    className="mb-4 text-accent group-hover:text-foreground transition-colors"
                  />
                  <h3 className="font-bold text-lg mb-3 uppercase tracking-wide">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="w-full h-1 bg-foreground" />

      {/* Why Choose Section */}
      <section className="w-full bg-background py-20 md:py-32">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 md:gap-20">
            {/* Left Column */}
            <div className="space-y-8">
              <div>
                <h2 className="text-4xl md:text-5xl font-black mb-4">
                  Why Artists
                  <br />
                  Choose Us
                </h2>
                <div className="w-12 h-1 bg-accent" />
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">
                We've obsessed over every detail—from brush responsiveness to color accuracy—so you can focus on what matters: your art.
              </p>
            </div>

            {/* Right Column - Key Points */}
            <div className="space-y-8">
              {[
                { title: "Zero Lag", description: "Instant brush response for natural drawing" },
                { title: "Precision", description: "Sub-pixel accuracy for detailed work" },
                { title: "Workflow", description: "Intuitive interface that gets out of your way" },
              ].map((point, index) => (
                <div
                  key={index}
                  className="border-l-4 border-accent pl-6 py-2 hover:border-foreground transition-colors duration-300"
                >
                  <h3 className="font-bold text-lg mb-2 uppercase tracking-wide">
                    {point.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{point.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="w-full h-1 bg-foreground" />

      {/* Supported Formats Section */}
      <section className="w-full bg-secondary py-16 md:py-24 border-y-4 border-foreground">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center space-y-8">
            <div>
              <h3 className="font-bold text-sm uppercase tracking-widest text-gray-600 mb-4">
                Export & Import
              </h3>
              <p className="text-lg text-gray-700">
                Work with industry-standard formats: , PNG, JPEG, and more coming soon
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Secondary CTA Section */}
      <section className="w-full bg-foreground text-background py-20 md:py-32">
        <div className="container max-w-3xl mx-auto px-4 text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-black leading-tight">
            Start Creating Today
          </h2>
          <p className="text-lg md:text-xl opacity-90 max-w-xl mx-auto">
            Join thousands of artists using our platform to bring their visions to life.
          </p>
          <div className="pt-4">
            <button
              onClick={handleLaunchClick}
              className="btn-brutalist bg-background text-foreground border-2 border-background hover:bg-accent hover:text-foreground hover:border-accent inline-flex items-center gap-3"
            >
              Launch Drawing App Now
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full bg-background border-t-4 border-foreground py-12 md:py-16">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div>
              <h4 className="font-bold text-sm uppercase tracking-widest mb-4">
                Product
              </h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-foreground transition">Features</a></li>
                <li><a href="#" className="hover:text-foreground transition"></a></li>
                <li><a href="#" className="hover:text-foreground transition"></a></li>
                <li><a href="#" className="hover:text-foreground transition"></a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-sm uppercase tracking-widest mb-4">
                Community
              </h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-foreground transition">Gallery</a></li>
                <li><a href="#" className="hover:text-foreground transition">Forum</a></li>
                <li><a href="#" className="hover:text-foreground transition">Blog</a></li>
                <li><a href="#" className="hover:text-foreground transition">Discord</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-sm uppercase tracking-widest mb-4">
                Support
              </h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-foreground transition">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition">Contact</a></li>
                <li><a href="#" className="hover:text-foreground transition">Privacy</a></li>
                <li><a href="#" className="hover:text-foreground transition">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-600">
            <p>&copy; 2026 Drawing App. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-foreground transition">Twitter</a>
              <a href="#" className="hover:text-foreground transition">Instagram</a>
              <a href="#" className="hover:text-foreground transition">YouTube</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
